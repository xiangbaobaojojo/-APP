package com.example.cne_shop.bean.city.model;

/**
 * Created by 博 on 2017/7/27.
 */

public class DistrictModel {

    private String name ;
    private String zipcode ;

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
