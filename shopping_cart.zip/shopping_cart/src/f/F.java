package f;

public class F {
	public static final String CURRENT_LOGIN_USERNAME = "currentLoginUsername";
	public static final String PUBLIC_CART_NAME = "publicCart";
	public static final String PRIVATE_CART_NAME_PREFIX = "privateCart_";
	public static final String ORDERINFO_NAME_PREFIX = "orderInfo_";
}
