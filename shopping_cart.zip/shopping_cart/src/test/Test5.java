package test;

public class Test5 {

	public static void main(String[] args) {
		String publicCart = "3_33-4_44-1_11-2_22";
		String privateCart = "1_11-2_22-7_77-8_88";
		
		
		
		
		
		
		// ___________________1_22-2_44-7_77-8_88-3_33-4_44

		
		
	}

}
