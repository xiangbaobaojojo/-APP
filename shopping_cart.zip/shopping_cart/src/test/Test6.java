package test;

public class Test6 {

	public static void main(String[] args) {
		while (true) {
			System.out.println("abcabc");
		}
	}

}
