package test;

public class Test1 {

	public static void main(String[] args) {
		double a = 1.04;
		double b = 1.09;
		System.out.println(a * b);
	}

}
